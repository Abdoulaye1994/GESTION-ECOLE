@extends('Page.layouts.index')

@section('contenu')


<section class="section courses" id="courses">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <div class="section-heading">
            <h6>Programme</h6>
            <h2>Information</h2>
          </div>
        </div>
      </div>
      <ul class="event_filter">

        <li>
            <section id="hero" class="d-flex ">
                <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -25px">
                  <a href="#inscrire" class="btn-get-started">Inscription</a>
                </div>
              </section>
        </li>
        <li>
            <section id="hero" class="d-flex ">
                <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -25px">
                  <a href="#reinscrire" class="btn-get-started">Renscription</a>
                </div>
              </section>
        </li>
      </ul>

  </section>

<div class="contact-us section" id="inscrire" style="margin-top: -30px" >
    <div class="container">
      <div class="row">
        <div class="col-lg-6  align-self-center">
          <div class="section-heading">
            <h2>Inscription en ligne</h2>
            <h4>Veuillez remplir le formulaire ci-dessous pour inscrire votre enfant dans notre école.</h4>
            <div class="special-offer" >
              <span class="offer">off<br><em>50%</em></span>
              <h6>Valide: <em>24 April 2036</em></h6>
              <h4>Special Offer <em>50%</em> OFF!</h4>
              <a href="#"><i class="fa fa-angle-right"></i></a>
            </div>
          </div>

        </div>
        <div class="col-lg-6">
          <div class="">
            <div class="card">
                <div class="card-body" style="background-color: #7a6ad8; border-radius: 5px">
                  <h5 class="card-title">Inscription Nouveau Elèves</h5>

                  <form class="row ">
                    <div class="col-md-12">
                      <label for="inputName5" class="form-label">Nom et Prenom de l'élève</label>
                      <input type="text" class="form-control" id="inputName5">
                    </div>
                    <div class="col-md-6">
                      <label for="inputEmail5" class="form-label">Email</label>
                      <input type="email" class="form-control" id="inputEmail5">
                    </div>
                    <div class="col-md-6">
                      <label for="inputPassword5" class="form-label">Numero de Parent</label>
                      <input type="number" class="form-control" id="inputPassword5">
                    </div>
                    <div class="col-12">
                      <label for="inputAddress5" class="form-label">Address</label>
                      <input type="text" class="form-control" id="inputAddres5s" placeholder="1234 Main St">
                    </div>

                    <div class="col-12">
                      <label for="inputAddress2" class="form-label">Numero Matricule de l'élève</label>
                      <input type="number" class="form-control" id="inputAddress2" placeholder="">
                    </div>
                    <div class="col-md-4">
                        <label for="inputState" class="form-label">Classe</label>
                        <select id="inputState" class="form-select">
                          <option selected>Choose...</option>
                          <option>Maternelle I</option>
                          <option>Maternelle II</option>
                          <option>CI</option>
                          <option>CP</option>
                          <option>CE1</option>
                          <option>CE2</option>
                          <option>CM1</option>
                          <option>CM2</option>
                        </select>
                      </div>
                    <div class="col-md-4">
                      <label for="inputState" class="form-label">Statut</label>
                      <select id="inputState" class="form-select">
                        <option selected>Choose...</option>
                        <option>Nouveau</option>
                        <option>Ancien</option>
                      </select>
                    </div>
                    <div class="col-md-2">

                    </div>
                    <div class="col-12">
                      <div class="form-check">

                      </div>
                    </div>
                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>

                    </div>
                  </form><!-- End Multi Columns Form -->

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>



  </div>



<div class="contact-us section" id="reinscrire">
    <div class="container">
      <div class="row">
        <div class="col-lg-6  align-self-center">
          <div class="section-heading">

            <h2>Reinscription en ligne</h2>
            <h4>Veuillez remplir le formulaire ci-dessous pour reinscrire les anciens élèves dans notre école.</h4>
            <div class="special-offer" >
              <span class="offer">off<br><em>50%</em></span>
              <h6>Valide: <em>24 April 2036</em></h6>
              <h4>Special Offer <em>50%</em> OFF!</h4>
              <a href="#"><i class="fa fa-angle-right"></i></a>
            </div>
          </div>

        </div>
        <div class="col-lg-6">
          <div class="">
            <div class="card">
                <div class="card-body" style="background-color: #7a6ad8; border-radius: 5px">
                  <h5 class="card-title">Reinscription Ancien Elèves</h5>

                  <form class="row ">
                    <div class="col-md-12">
                      <label for="inputName5" class="form-label">Nom et Prenom de l'élève</label>
                      <input type="text" class="form-control" id="inputName5">
                    </div>
                    <div class="col-md-6">
                      <label for="inputEmail5" class="form-label">Email</label>
                      <input type="email" class="form-control" id="inputEmail5">
                    </div>
                    <div class="col-md-6">
                      <label for="inputPassword5" class="form-label">Numero de Parent</label>
                      <input type="number" class="form-control" id="inputPassword5">
                    </div>
                    <div class="col-12">
                      <label for="inputAddress5" class="form-label">Address</label>
                      <input type="text" class="form-control" id="inputAddres5s" placeholder="1234 Main St">
                    </div>
                    <div class="col-12">
                      <label for="inputAddress2" class="form-label">Numero Matricule de l'élève</label>
                      <input type="number" class="form-control" id="inputAddress2" placeholder="">
                    </div>
                    <div class="col-md-4">
                        <label for="inputState" class="form-label">Classe</label>
                        <select id="inputState" class="form-select">
                          <option selected>Choose...</option>
                          <option>Maternelle I</option>
                          <option>Maternelle II</option>
                          <option>CI</option>
                          <option>CP</option>
                          <option>CE1</option>
                          <option>CE2</option>
                          <option>CM1</option>
                          <option>CM2</option>
                        </select>
                      </div>
                    <div class="col-md-4">
                      <label for="inputState" class="form-label">Statut</label>
                      <select id="inputState" class="form-select">
                        <option selected>Choose...</option>
                        <option>Nouveau</option>
                        <option>Ancien</option>
                      </select>
                    </div>
                    <div class="col-md-2">

                    </div>
                    <div class="col-12">
                      <div class="form-check">

                      </div>
                    </div>
                    <div class="text-center">
                      <button type="submit" class="btn btn-primary">Submit</button>

                    </div>
                  </form><!-- End Multi Columns Form -->

                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div>



  </div>



@endsection
