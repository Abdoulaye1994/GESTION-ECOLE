@extends('Page.layouts.index')

@section('contenu')

  <div class="row event_box" style="margin-top: 190px">
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6 design">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-01.jpg" alt=""></a>
          <span class="category">Webdesign</span>
          <span class="price"><h6><em>$</em>160</h6></span>
        </div>
        <div class="down-content">
          <span class="author">Stella Blair</span>
          <h4>Learn Web Design</h4>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6  development">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-02.jpg" alt=""></a>
          <span class="category">Development</span>
          <span class="price"><h6><em>$</em>340</h6></span>
        </div>
        <div class="down-content">
          <span class="author">Cindy Walker</span>
          <h4>Web Development Tips</h4>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6 design wordpress">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-03.jpg" alt=""></a>
          <span class="category">Wordpress</span>
          <span class="price"><h6><em>$</em>640</h6></span>
        </div>
        <div class="down-content">
          <span class="author">David Hutson</span>
          <h4>Latest Web Trends</h4>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6 development">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-04.jpg" alt=""></a>
          <span class="category">Development</span>
          <span class="price"><h6><em>$</em>450</h6></span>
        </div>
        <div class="down-content">
          <span class="author">Stella Blair</span>
          <h4>Online Learning Steps</h4>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6 wordpress development">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-05.jpg" alt=""></a>
          <span class="category">Wordpress</span>
          <span class="price"><h6><em>$</em>320</h6></span>
        </div>
        <div class="down-content">
          <span class="author">Sophia Rose</span>
          <h4>Be a WordPress Master</h4>
        </div>
      </div>
    </div>
    <div class="col-lg-4 col-md-6 align-self-center mb-30 event_outer col-md-6 wordpress design">
      <div class="events_item">
        <div class="thumb">
          <a href="#"><img src="../build/template/assets/images/course-06.jpg" alt=""></a>
          <span class="category">Webdesign</span>
          <span class="price"><h6><em>$</em>240</h6></span>
        </div>
        <div class="down-content">
          <span class="author">David Hutson</span>
          <h4>Full Stack Developer</h4>
        </div>
      </div>
    </div>
  </div>
</div>



@endsection
