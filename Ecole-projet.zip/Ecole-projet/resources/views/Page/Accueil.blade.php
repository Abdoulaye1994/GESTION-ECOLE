<!DOCTYPE html>
<html lang="fr">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Scholar - Online School HTML5 Template</title>

    <!-- Bootstrap core CSS -->
    <link href="../build/template/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="../build/template/assets/css/fontawesome.css">
    <link rel="stylesheet" href="../build/template/assets/css/templatemo-scholar.css">
    <link rel="stylesheet" href="../build/template/assets/css/owl.css">
    <link rel="stylesheet" href="../build/template/assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 586 Scholar

https://templatemo.com/tm-586-scholar

-->
  </head>

<body>

  <!-- ***** Preloader Start ***** -->
  <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.html" class="logo">
                        <h1>Scholar</h1>
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Serach Start ***** -->
                    <div class="search-input">
                      <form id="search" action="#">
                        <input type="text" placeholder="Type Something" id='searchText' name="searchKeyword" onkeypress="handle" />
                        <i class="fa fa-search"></i>
                      </form>
                    </div>
                    <!-- ***** Serach Start ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                      <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
                      <li class="scroll-to-section"><a href="#services">Services</a>
                    </li>

                      <li class="scroll-to-section"><a href="#courses">Infos</a></li>
                      <li class="scroll-to-section"><a href="#team">Team</a></li>
                      <li class="scroll-to-section"><a href="#contact">Contact Us</a></li>
                      <li class="scroll-to-section"><a href=" {{ route('register') }}"> <i class="far fa-user mr-2 tm-logout-icon"></i></a> </li>
                  </ul>
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="main-banner" id="top">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="owl-carousel owl-banner">
            <div class="item item-1">
              <div class="header-text">
                <h2>Learning Today,<br> Leading Tomorrow</h2>
                <section id="hero" class="d-flex justify-content-center align-items-center">
                    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -20px">
                      <a href="{{ route('inscrit') }}" class="btn-get-started">INSCRIVEZ VOTRE ENFANT</a>
                    </div>
                  </section>
              </div>
            </div>
            <div class="item item-2">
              <div class="header-text">

                <h2>Get the best result out of your effort</h2>
                <section id="hero" class="d-flex justify-content-center align-items-center">
                    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -20px">
                      <a href="{{ route('inscrit') }}" class="btn-get-started">INSCRIVEZ VOTRE ENFANT</a>
                    </div>
                  </section>
              </div>
            </div>
            <div class="item item-3">
              <div class="header-text">
                <h2>Online Learning helps you save the time</h2>
                <section id="hero" class="d-flex justify-content-center align-items-center">
                    <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -20px">
                      <a href="{{ route('inscrit') }}" class="btn-get-started">INSCRIVEZ VOTRE ENFANT</a>
                    </div>
                  </section>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

   <!-- ======= SUITE Section ======= -->
   <section id="about" class="about" style="margin-top: 30px">
    <div class="container" data-aos="fade-up">

      <div class="row">
        <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left" data-aos-delay="100">
          <img src="../build/template/assets/images/covid.jpg" class="img-fluid" alt="">
        </div>
        <div class="col-lg-6 pt-4 pt-lg-0 order-2 order-lg-1 content">
          <h1 style="font-size: 3.5rem;
          font-weight: 400;
          line-height: 3.5rem;">Merci d'avoir choisir notre Ecole</h1> <br>
          <p class="fst-italic" style="  font-size: 2 rem;
          color:  #0f1e6a;
          margin-bottom: 2rem;">
            En faisant le choix, d'inscrire  vos enfnts, vous lui garantissez une éducation  de qualité, enthousiaste et investi, ainsi qu’une communauté bienveillante où chaque élève est accompagné du début à la fin de ses études.
          </p>
        </div>
      </div>

    </div>
  </section><!-- FIN SUITE Section -->

  <div class="services section" id="services" style="margin-top: 30px">
    <div class="container">
      <div class="row">
        <div class="col-lg-4 col-md-6">
          <div class="service-item">
            <div class="icon">
              <img src="../build/template/assets/images/service-01.png" alt="online degrees">
            </div>
            <div class="main-content">
              <h4>Formulaire <br> Inscription</h4>
              <p>Whenever you need free templates in HTML CSS, you just remember TemplateMo website.</p>
              <div class="main-button">
                <a href="{{ route('inscrit') }}">Read More</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-item">
            <div class="icon">
              <img src="../build/template/assets/images/service-02.png" alt="short courses">
            </div>
            <div class="main-content">
              <h4>Paiement <br> Frais Inscription</h4>
              <p>You can browse free templates based on different tags such as digital marketing, etc.</p>
              <div class="main-button">
                <a href="{{ route('frais') }}">Read More</a>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 col-md-6">
          <div class="service-item">
            <div class="icon">
              <img src="../build/template/assets/images/service-03.png" alt="web experts">
            </div>
            <div class="main-content">
              <h4>Espace <br> Parents</h4>
              <p>You can start learning HTML CSS by modifying free templates from our website too.</p>
              <div class="main-button">
                <a href="{{ route('espaceparent') }}">Read More</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


  <section class="section courses" id="courses" style="margin-top: 30px" >
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <div class="section-heading">
            <h6>Programme</h6>
            <h2>Information</h2>
          </div>
        </div>
      </div>
      <ul class="event_filter">
        <li>
            <section id="hero" class="d-flex ">
                <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -25px">
                  <a href="{{ route('blogspot') }}" class="btn-get-started">Blog</a>
                </div>
              </section>
        </li>
        <li>
            <section id="hero" class="d-flex ">
                <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -25px">
                  <a href="{{ route('pro') }}" class="btn-get-started">Programme</a>
                </div>
              </section>
        </li>
        <li>
            <section id="hero" class="d-flex ">
                <div class="container position-relative" data-aos="zoom-in" data-aos-delay="100" style="margin-top: -25px">
                  <a href="{{ route('photo') }}" class="btn-get-started">Galérie</a>
                </div>
              </section>
        </li>
      </ul>

  </section>

  <div class="section fun-facts" style="margin-top: 30px">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="wrapper">
            <div class="row">
              <div class="col-lg-3 col-md-6">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="150" data-speed="1000"></h2>
                   <p class="count-text ">Happy Students</p>
                </div>
              </div>
              <div class="col-lg-3 col-md-6">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="804" data-speed="1000"></h2>
                  <p class="count-text ">Course Hours</p>
                </div>
              </div>
              <div class="col-lg-3 col-md-6">
                <div class="counter">
                  <h2 class="timer count-title count-number" data-to="50" data-speed="1000"></h2>
                  <p class="count-text ">Employed Students</p>
                </div>
              </div>
              <div class="col-lg-3 col-md-6">
                <div class="counter end">
                  <h2 class="timer count-title count-number" data-to="15" data-speed="1000"></h2>
                  <p class="count-text ">Years Experience</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  
  <div class="team section" id="team" style="margin-top: -30px">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <div class="team-member">
            <div class="main-content">
              <img src="../build/template/assets/images/member-01.jpg" alt="">
              <span class="category">UX Teacher</span>
              <h4>Sophia Rose</h4>
              <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="team-member">
            <div class="main-content">
              <img src="../build/template/assets/images/member-02.jpg" alt="">
              <span class="category">Graphic Teacher</span>
              <h4>Cindy Walker</h4>
              <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="team-member">
            <div class="main-content">
              <img src="../build/template/assets/images/member-03.jpg" alt="">
              <span class="category">Full Stack Master</span>
              <h4>David Hutson</h4>
              <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-lg-3 col-md-6">
          <div class="team-member">
            <div class="main-content">
              <img src="../build/template/assets/images/member-04.jpg" alt="">
              <span class="category">Digital Animator</span>
              <h4>Stella Blair</h4>
              <ul class="social-icons">
                <li><a href="#"><i class="fab fa-facebook"></i></a></li>
                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                <li><a href="#"><i class="fab fa-linkedin"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="section testimonials">
    <div class="container">
      <div class="row">
        <div class="col-lg-7">
          <div class="owl-carousel owl-testimonials">
            <div class="item">
              <p>“Please tell your friends or collegues about TemplateMo website. Anyone can access the website to download free templates. Thank you for visiting.”</p>
              <div class="author">
                <img src="../build/template/assets/images/testimonial-author.jpg" alt="">
                <span class="category">Full Stack Master</span>
                <h4>Claude David</h4>
              </div>
            </div>
            <div class="item">
              <p>“Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravid.”</p>
              <div class="author">
                <img src="../build/template/assets/images/testimonial-author.jpg" alt="">
                <span class="category">UI Expert</span>
                <h4>Thomas Jefferson</h4>
              </div>
            </div>
            <div class="item">
              <p>“Scholar is free website template provided by TemplateMo for educational related websites. This CSS layout is based on Bootstrap v5.3.0 framework.”</p>
              <div class="author">
                <img src="../build/template/assets/images/testimonial-author.jpg" alt="">
                <span class="category">Digital Animator</span>
                <h4>Stella Blair</h4>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-5 align-self-center">
          <div class="section-heading">
            <h6>TESTIMONIALS</h6>
            <h2>Nos meilleur Elèves aux différentes examen</h2>
            <p>You can search free CSS templates on Google using different keywords such as templatemo portfolio, templatemo gallery, templatemo blue color, etc.</p>
          </div>
        </div>
      </div>
    </div>
  </div>


  <div class="contact-us section" id="contact">
    <div class="container">
      <div class="row">
        <div class="col-lg-6  align-self-center">
          <div class="section-heading">
            <h6>Contact Us</h6>
            <h2>Feel free to contact us anytime</h2>
            <p>Thank you for choosing our templates. We provide you best CSS templates at absolutely 100% free of charge. You may support us by sharing our website to your friends.</p>
            <div class="special-offer">
              <span class="offer">off<br><em>50%</em></span>
              <h6>Valide: <em>24 April 2036</em></h6>
              <h4>Special Offer <em>50%</em> OFF!</h4>
              <a href="#"><i class="fa fa-angle-right"></i></a>
            </div>
          </div>
        </div>
        <div class="col-lg-6">
          <div class="contact-us-content">
            <form id="contact-form" action="" method="post">
              <div class="row">
                <div class="col-lg-12">
                  <fieldset>
                    <input type="name" name="name" id="name" placeholder="Your Name..." autocomplete="on" required>
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your E-mail..." required="">
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <textarea name="message" id="message" placeholder="Your Message"></textarea>
                  </fieldset>
                </div>
                <div class="col-lg-12">
                  <fieldset>
                    <button type="submit" id="form-submit" class="orange-button">Send Message Now</button>
                  </fieldset>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2036 Scholar Organization. All rights reserved. &nbsp;&nbsp;&nbsp; Design: <a href="https://templatemo.com" rel="nofollow" target="_blank">TemplateMo</a></p>
      </div>
    </div>
  </footer>

  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="../build/template/vendor/jquery/jquery.min.js"></script>
  <script src="../build/template/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="../build/template/assets/js/isotope.min.js"></script>
  <script src="../build/template/assets/js/owl-carousel.js"></script>
  <script src="../build/template/assets/js/counter.js"></script>
  <script src="../build/template/assets/js/custom.js"></script>

  </body>
</html>
