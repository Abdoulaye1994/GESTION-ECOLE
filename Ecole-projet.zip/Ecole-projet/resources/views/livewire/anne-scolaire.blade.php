<div>

    <!DOCTYPE html>
    <html lang="en">

    <head>
      <meta charset="utf-8">
      <meta content="width=device-width, initial-scale=1.0" name="viewport">

      <title>Dashboard - NiceAdmin Bootstrap Template</title>
      <meta content="" name="description">
      <meta content="" name="keywords">

      <!-- Favicons -->
      <link href="../build/nice/assets/img/favicon.png" rel="icon">
      <link href="../build/nice/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

      <!-- Google Fonts -->
      <link href="https://fonts.gstatic.com" rel="preconnect">
      <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

      <!-- Vendor CSS Files -->
      <link href="../build/nice/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/quill/quill.snow.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
      <link href="../build/nice/assets/vendor/simple-datatables/style.css" rel="stylesheet">

      <!-- Template Main CSS File -->
      <link href="../build/nice/assets/css/style.css" rel="stylesheet">
     </head>

     <body>


    <div class="">

        <div class="card">
          <div class="card-body">
           <div class="d-flex justify-content-between">
            <div class="col-md-4">

                <input type="text" class="form-control"  placeholder="Recherche"  id="inputEmail4" style="margin-left: 20px;margin-top: 20px" wire:model.live="search">

            </div>
            <h5 class="card-title"><a href=" {{ route('years') }} "><button type="button" class="btn btn-primary">Nouvelle Année Scolaire</button></a></h5>
           </div>


           @if (Session::get('sucess'))
           <div> {{ Session::get('sucess') }} </div>
      @endif


            <table class="table table-striped">
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">Années Scolaires</th>
                  <th scope="col">Année actuelle</th>
                  <th scope="col">Active</th>
                  <th scope="col">Action</th>
                </tr>
              </thead>

              <tbody>

              @forelse ($schoolYearList as $item)
              <tr>
                <th scope="col"> {{ $item->id }} </th>
                <th scope="col"> {{ $item->school_year }} </th>
                <th scope="col">{{ $item->anne_actuel }} </th>
                <th scope="col">

                    @if($item->active >= 1)
                        <span  class="badge bg-success">Actif</span>
                    @else
                         <span class="badge bg-danger">Inactif</span>
                    @endif
                </th>

                <th scope="col">
                    @if ($item->active >= 1)
                       <button  type="button" class="btn btn-danger" wire:click='toggleStatus( {{ $item->id }} )'>Rendre Inactif</button>
                    @else
                    <button  type="button" class="btn btn-success" wire:click='toggleStatus( {{ $item->id }} )'>Rendre Actif</button>
                    @endif

                </th>
              </tr>
              @empty
              <tr>
                <td>
                    <div>Aucun Elément Trouver</div>
                </td>
            </tr>
              @endforelse


              </tbody>
            </table>


                <div class="mt-5"> {{ $schoolYearList->links() }} </div>

               <!-- ======= Footer ======= -->
  <footer id="footer" class="footer" style="margin: auto">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../build/nice/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="../build/nice/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../build/nice/assets/vendor/chart.js/chart.umd.js"></script>
  <script src="../build/nice/assets/vendor/echarts/echarts.min.js"></script>
  <script src="../build/nice/assets/vendor/quill/quill.min.js"></script>
  <script src="../build/nice/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="../build/nice/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="../build/nice/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../build/nice/assets/js/main.js"></script>

</body>

</html>

</div>
