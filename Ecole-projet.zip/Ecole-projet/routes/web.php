<?php

use App\Http\Controllers\DashborController;
use App\Http\Controllers\DashController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LevelController;
use App\Http\Controllers\NiveauxController;
use App\Http\Controllers\StudentController;
use App\Livewire\LevelSchool;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('Page.Accueil');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');
});


Route::get('/home', [HomeController::class, 'indexhome'])->name('home');
Route::get('/inscrption', [HomeController::class, 'indexinscrit'])->name('inscrit');
Route::get('/espace', [HomeController::class, 'indexparent'])->name('espaceparent');
Route::get('/blog', [HomeController::class, 'indexblog'])->name('blogspot');
Route::get('/paiement', [HomeController::class, 'indexpaiement'])->name('frais');

Route::get('/programme', [HomeController::class, 'indexpro'])->name('pro');
Route::get('/galerie', [HomeController::class, 'indexgal'])->name('photo');


/*---------------- Dashbor Controller -------------------*/

Route::prefix('Scolaire')-> group(function(){
    Route::get('/scolaire', [DashborController::class, 'indexscolaire'])->name('Anne');
    Route::get('/create', [DashborController::class, 'indexcreate'])->name('years');
    Route::post('/create', [DashborController::class, 'indexcreate'])->name('Create');

});

Route::prefix('Niveau')-> group(function(){
   Route::get('/niveau', [DashborController::class, 'indexniveau'])->name('Level');
   Route::get('/createnive', [DashborController::class, 'indexnive'])->name('niveaux');
   Route::post('/createnive', [DashborController::class, 'indexnive'])->name('Createnive');
});

Route::get('/edite/{level}', [LevelController::class, 'edit'])->name('edition.level');
Route::post('/edite/{level}', [LevelController::class, 'edit'])->name('editeur.level');


Route::prefix('Liste')->group(function(){
    Route::get('/list', [DashController::class, 'indexlist'])->name('lister');
});


Route::prefix('classes')->group(function(){
    Route::get('/', [LevelController::class, 'index'])->name('classes');
    Route::get('/create', [LevelController::class, 'created'])->name('classes.create');
});

Route::prefix('eleves')->group(function(){
   Route::get('/', [StudentController::class, 'index'])->name('Students');
   Route::get('/{eleve}', [StudentController::class, 'show'])->name('students.show');
   Route::get('/create', [StudentController::class, 'create'])->name('students.create');
   Route::get('/edit/{eleve}', [StudentController::class, 'edit'])->name('students.edit');

});

Route::prefix('niveaux')->group(function(){
    Route::get('/', [NiveauxController::class, 'index'])->name('niveaux.index');
    Route::get('/create', [NiveauxController::class, 'create'])->name('niveaux');
});

Route::get('/editeur', [NiveauxController::class, 'editeur'])->name('editions.niveau');



