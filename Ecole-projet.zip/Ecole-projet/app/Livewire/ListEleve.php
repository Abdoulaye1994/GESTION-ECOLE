<?php

namespace App\Livewire;

use Livewire\Component;

class ListEleve extends Component
{
    public function render()
    {
        return view('livewire.list-eleve');
    }
}
