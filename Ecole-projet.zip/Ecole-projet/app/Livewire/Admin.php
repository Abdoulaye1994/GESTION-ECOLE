<?php

namespace App\Livewire;

use Livewire\Component;

class Admin extends Component
{
    public function render()
    {
        return view('livewire.admin');
    }
}
